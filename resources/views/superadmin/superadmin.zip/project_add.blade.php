@extends('superadmin_layout')
   @section('content')
   <style>
#myProgress {
  width: 100%;
  background-color: #ddd;
}

#myBar {
  width: 10%;
  height: 30px;
  background-color: #4CAF50;
  text-align: center;
  line-height: 30px;
  color: white;
}
</style>


<div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                 
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Projects</h4>
                            </div>
                            <div class="col-sm-6">
                                <h4 class="page-title project_super">Supertech</h4>
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="add_project_wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/Project-add')}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">

                                            @if(session('role') == 'admin' || session('role') == 'project_Manager')
                                            @php(
                                            
                                            $org = DB::table('grc_organization')->where('id',session('org_id'))->get()
                                            
                                            )
                                               <div class="form-group">
                                                <label for="organizationname">Organization Name</label><span style="color:red;">*</span>
                                                <select name="organizationname" id="organizationname" class="form-control project_box" readonly>
                                                  <option value="">Select Option</option>
                                                    @foreach($org as $orgData)
                                                    <option value="{{$orgData->id}}" @if(session('org_id') == $orgData->id) selected @endif>{{$orgData->org_name}}</option>
                                                    @endforeach
                                                </select>
                                                   @error('organizationname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                             @else
                                            
                                                <div class="form-group">
                                                <label for="organizationname">Organization Name</label><span style="color:red;">*</span>
                                                <select name="organizationname" id="organizationname" class="form-control project_box">
                                                  <option value="">Select Option</option>
                                                    @foreach($orgname as $orgData)
                                                    <option value="{{$orgData->id}}">{{$orgData->org_name}}</option>
                                                    @endforeach
                                                </select>
                                                   @error('organizationname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div> 
                                           @endif
                                          <!--   <div class="form-group">
                                                <label for="organizationname">Organization Name</label>
                                                <select name="organizationname" id="organizationname" class="form-control project_box">
                                                    @foreach($orgname as $orgData)
                                                    <option value="{{$orgData->id}}">{{$orgData->org_name}}</option>
                                                    @endforeach
                                                </select>
                                               
                                            </div> -->
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectname">Project Name</label><span style="color:red;">*</span>
                                                <input type="text" name="projectname" id="projectname" value="{{ old('projectname') }}" maxlenght="60" class="form-control project_box">
                                                  @error('projectname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectalias">Project Location</label><span style="color:red;">*</span>
                                                <input type="text" name="projectalias" value="{{ old('projectalias') }}" id="projectalias" maxlenght="60" class="form-control project_box">
                                                 @error('projectalias')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                     
                                   <?php  $pmname = DB::table('grc_user');
                                   if(session('role') !='superadmin' && !empty(session('org_id'))){
                                       
                                    // $pmname->where('org_id',session('org_id'));
                                    
                                    $pmname->where('created_by',session('userId'));
                                     
                                   }
                                    //$pmname->where('created_by',session('userId'));
                                  
                                    $manager= $pmname->where('role','project_Manager')->get();

                                   ?>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectalias">Project Manager</label><span style="color:red;">*</span>
                                                
                                                 <select name="projectmanager"  class="form-control project_box">
                                                  <option value="">Select Option</option>
                                                     @foreach($manager as $pm)
                                                     <option value="{{$pm->id}}">{{$pm->first_name}}  {{$pm->last_name}}</option>
                                                     @endforeach
                                                 </select>
                                                   @error('projectmanager')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                                 
                                                
                                            </div>
                                        </div>

                                        <!--<div class="col-xs-12 col-sm-6">-->
                                        <!--    <div class="form-group">-->
                                        <!--        <label for="projectalias">Password</label><span style="color:red;">*</span>-->
                                                
                                        <!--         <input type="password" name="propassword" class="form-control project_box">-->
                                        <!--           @error('propassword')-->
                                        <!--        <div style="color:red;">{{ $message }}</div>-->
                                        <!--        @enderror-->
                                                
                                                
                                        <!--    </div>-->
                                        <!--</div>-->

                                        <div class="col-xs-12 col-sm-6">
                                            <?php  $typelist = DB::table('grc_type')->get();?>
                                            <div class="form-group">
                                                <label for="projecttype">Project Type</label><span style="color:red;">*</span>
                                                <select name="projecttype" id="projecttype" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    @foreach($typelist as $value)
                                                    <option value="{{$value->type_name}}">{{$value->type_name}}</option>
                                                    @endforeach
                                                </select>

                                                  @error('projecttype')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <?php  $stagelist = DB::table('grc_stages')->get();?>
                                            <div class="form-group">
                                                <label for="projectstage">Type Of NOC</label><span style="color:red;">*</span>
                                                <select name="projectstage" id="projectstage" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                      @foreach($stagelist as $value)
                                                    <option value="{{$value->stage_name}}">{{$value->stage_name}}</option>
                                                    @endforeach
                                                </select>

                                                 @error('projectstage')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="pincode">Pin Code</label><span style="color:red;">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="pincode" id="pincode" value="{{ old('pincode') }}"  maxlength="6" class="form-control project_box">
                                                  @error('pincode')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="landmark">Landmark</label><span style="color:red;">*</span>
                                                <input type="text" name="landmark" id="landmark" value="{{ old('landmark') }}" maxlenght="60" class="form-control project_box">
                                                  @error('landmark')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <?php  $typelist = DB::table('grc_sector')->get();?>
                                            <div class="form-group">
                                                <label for="sector">Sector</label><span style="color:red;">*</span>
                                                <select name="sector" id="sector" class="form-control project_box">
                                                    
                                                    <option value="">Select Option</option>
                                                    @foreach($typelist as $value)
                                                    <option value="{{$value->sector_name}}">{{$value->sector_name}}</option>
                                                    @endforeach
                                                
                                                </select>

                                                 @error('sector')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectstate">State</label><span style="color:red;">*</span>
                                                <select name="projectstate" id="projectstate" class="form-control project_box">
                                                  <option value="">Select Option</option>
                                                    @foreach($CData as $result)
                                                    <option value="{{$result['stateid']}}">{{$result['statename']}}</option>
                                                    @endforeach
                                                </select>

                                                 @error('projectstate')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                         
                                         

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectcity">City</label><span style="color:red;">*</span>
                                                <select name="projectcity" id="projectcity" class="form-control project_box citylist">

                                             
                                                </select>
                                                  @error('projectcity')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                         <?php 
                                         $currency = DB::table('main_currency')->where('isactive',1)->get();
                                         ?>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectcurrency">Currency</label><span style="color:red;">*</span>
                                                <select name="projectcurrency" id="projectcurrency" class="form-control project_box">
                                                    @foreach($currency as $value)
                                                    <option value="{{$value->id}}">{{$value->currencycode}}</option>
                                                   @endforeach
                                                </select>

                                                  @error('projectcurrency')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <?php  $statuslist = DB::table('grc_status')->get();?>
                                                <label for="prstatus">Project Status</label><span style="color:red;">*</span>
                                                <select name="prstatus" id="prstatus" class="form-control project_box">
                                                   <option value="">Select Option</option>
                                                    @foreach($statuslist as $value)
                                                    <option value="{{$value->status_name}}">{{$value->status_name}}</option>
                                                    @endforeach
                                                </select>

                                                  @error('prstatus')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="estimatedhrs">Project Estimated Hours</label><span style="color:red;">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="estimatedhrs" id="estimatedhrs"  maxlength="4"  value="{{ old('estimatedhrs') }}" class="form-control project_box">

                                                 @error('estimatedhrs')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                                
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectstart">Start Date</label><span style="color:red;">*</span>
                                                <input type="text" placeholder="dd/mm/yyyy" name="projectstart" id="projectstart" value="{{ old('projectstart') }}" class="dateTxt form-control project_box">
                                                 @error('projectstart')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectend">End Date</label><span style="color:red;">*</span>
                                                <input type="text" placeholder="dd/mm/yyyy" name="projectend" id="projectend" value="{{ old('projectend') }}" class="dateTxt form-control project_box">
                                                 @error('projectend')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="prDescription">Project Description</label><span style="color:red;">*</span>
                                                <textarea rows="4" name="prDescription" id="prDescription" class="form-control project_box">{{ old('prDescription') }}</textarea>
                                                  @error('prDescription')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        

                                        <div class="col-xs-12 col-sm-12 text-center">
                                                <button type="button" data-toggle="modal" data-target="#exampleModalScrollable" class="previvew_btn" onclick="getprojectValue();">Preview</button>
                                                <input type="submit" name="submit"  value="Submit" class="submit_btn">
                                        </div>

                                        <!-- <div class="col-xs-12 col-sm-6">
                                            <div class="see_details">
                                                <p>Click <a href="project_details.html">here</a> to see project details.</p>
                                            </div>
                                        </div> -->
                                    </div>
                                </form> 
                            </div>
                        </div>
                        <!-- end row -->
                    </div>

                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
<div class="modal fade bd-example-modal-xl" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="preview_mode">
                    <div class="row">
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Organization Name</label>
                                <p id="previewproorg"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Project Name</label>
                                <p id="previewproname"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Project Alias</label>
                                <p id="previewproalias"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Project Stage</label>
                                <p id="previewprostage">Housing Property</p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Project Type</label>
                                <p id="previewprotype"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Pin Code</label>
                                <p id="previewpropincode"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Landmark</label>
                                <p id="previewprolandmark"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Sector</label>
                                <p id="previewprosector"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>State</label>
                                <p id="previewprostate"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>City</label>
                                <p id="previewprocity"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Currency</label>
                                <p id="previewprocurrency"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Project Status</label>
                                <p id="previewprostatus"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Estimate hours</label>
                                <p id="previewproestimate"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Start Date</label>
                                <p id="previewprostart"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>End Date</label>
                                <p id="previewproend"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12">
                            <div class="form-group">
                                <label>Project Description</label>
                                <p id="previewprodes"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
@stop

@section('extra_js')

<script>

$(document).on('click','.submit_btn',function(){
    
    fromdate = $('#projectstart').val();
    todate = $('#projectend').val();
    
    
      var d1 = Date.parse(fromdate);
                  var d2 = Date.parse(todate);
                  if (d1 > d2) {
                      alert ("Please Select Valid Date");
                      var error = 0;
                      return false;
                  }
    
});
$(function(){$('.dateTxt').datepicker(); }); 
</script>

@stop