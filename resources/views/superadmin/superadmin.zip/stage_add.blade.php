 @extends('superadmin_layout')
   @section('content')
            <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Stage</h4>
                            </div>
                           
                        </div>
                    </div>
                </div>
                <div class="add_project_wrapper add_org_wrapper">
                    <div class="container-fluid">
                         <div class="col-xs-8">
                        @if(Session::has('msg'))
                        <p class="alert alert-info">{{ Session::get('msg') }}</p>
                        @endif

                        @if ($message = Session::get('warning-type'))
                        <div class="alert alert-danger alert-block">
                          <strong>{{ $message }}</strong>
                        </div>
                        @endif
                </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/stage-management')}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                               
                                              
                                                Add Stage
                                                <input type="text" name="stage" maxlength="60" class="form-control project_box" autofill="false">
                                               
                                               
                                            </div>
                                        </div>


                                        <div class="col-xs-12 col-sm-6"></div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                        
                                                <input type="submit" name="submit" value="Submit" class="submit_btn" style="margin-top: 166px;">
                                            </div>
                                        </div>

                                    
                                    </div>
                                </form> 
                               <!--   <table  class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%; margin-top: 92px;">
                                        <thead>
                                            <tr>
                                                <th>S. No.</th>
                                                <th>Country</th>
                                                <th>Created Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1?>
                                           
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td></td>
                                                <td></td>
                                                 <td>
                                                    <a href="#"><i class="mdi mdi-delete text-danger" data-toggle="modal"
                                                               data-target="#deletemp" title="Delete"></i></a>
                                                </td>
                                            </tr>
                                          
                                        </tbody>
                                    </table> -->
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
    </div>
   
</div>
<!-- /.modal-dialog -->
</div>
@stop