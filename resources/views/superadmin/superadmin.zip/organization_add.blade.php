 @extends('superadmin_layout')
   @section('content')
            <!-- ============================================================== -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Organization</h4>
                            </div>
                            <div class="col-sm-6">
                               <!--  <h4 class="page-title project_super">Supertech</h4> -->
                            </div>
                        </div>
                    </div>
                </div>
                
             

                <div class="add_project_wrapper add_org_wrapper">
                    
                    <div class="container-fluid">
                        <div class="col-xs-8">
                        @if(Session::has('org-success'))
                        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('org-success') }}</p>
                        @endif
                        
                        @if ($message = Session::get('warning-org'))
                        <div class="alert alert-danger alert-block">
                          <strong>{{ $message }}</strong>
                        </div>
                        @endif

                        @if ($message = Session::get('required-org'))
                        <div class="alert alert-danger alert-block">
                          <strong>{{ $message }}</strong>
                        </div>
                        @endif
                </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/Organization-add')}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgname">Organization Name</label><span style="color:red;">*</span>
                                                <input type="text" name="orgname" id="orgname" maxlenght="60" class="form-control project_box" value="{{ old('orgname') }}">
                                                @error('orgname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror

                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgemail">Organization Email</label><span style="color:red;">*</span>
                                                <input type="email" name="orgemail" id="orgemail" value="{{ old('orgemail') }}" class="form-control project_box">
                                                 @error('orgemail')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                       <!--  <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="uname">User Name</label>
                                                <input type="text" name="uname" id="uname" class="form-control project_box" autofill="false">
                                            </div>
                                        </div> -->
                                        <?php  $adminname = DB::table('grc_user')->where('role','admin')->where('status', 1)->get(); ?>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="uname">Admin Name</label><span style="color:red;">*</span>
                                                <select name="adminname" id="adminname" class="form-control project_box" autofill="false">
                                                    <option value="">Select Option</option>
                                                    @foreach($adminname as $admin)
                                                    @if(empty($admin->org_id))
                                                    <option value="{{$admin->id}}">{{$admin->first_name}} {{$admin->last_name}}</option>
                                                    @endif
                                                    @endforeach
                                                </select>
                                                 @error('adminname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>
                                        
                                        <!--<div class="col-xs-12 col-sm-6">-->
                                        <!--    <div class="form-group">-->
                                        <!--        <label for="upassword">Password</label><span style="color:red;">*</span>-->
                                        <!--        <input type="password" name="upassword" id="txtNewPassword" class="form-control project_box" autofill="false">-->
                                        <!--         @error('upassword')-->
                                        <!--        <div style="color:red;">{{ $message }}</div>-->
                                        <!--        @enderror-->
                                        <!--    </div>-->
                                        <!--</div>-->

                                        <!--<div class="col-xs-12 col-sm-6">-->
                                        <!--    <div class="form-group">-->
                                        <!--        <label for="confirmpassword">Confirm Password</label><span style="color:red;">*</span>-->
                                        <!--        <input type="password" name="confirmpassword" id="txtConfirmPassword" onChange="checkPasswordMatch();" class="form-control project_box">-->
                                        <!--    </div>-->
                                        <!--     <div class="registrationFormAlert" id="divCheckPasswordMatch">-->
                                        <!--         @error('confirmpassword')-->
                                        <!--        <div style="color:red;">{{ $message }}</div>-->
                                        <!--        @enderror-->
                                        <!--</div>-->
                                        <!--</div>-->
                                       

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgmobile">Mobile No.</label><span style="color:red;">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)"  name="orgmobile" id="orgmobile" class="form-control project_box" value="{{ old('orgmobile') }}"  minlength="10" maxlength="10">
                                                 @error('orgmobile')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <!-- <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgphone">Phone No.</label>
                                                <input type="text" name="orgphone" id="orgphone" class="form-control project_box" title="Format: 0000-000-0000" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}">
                                            </div>
                                        </div> -->

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgalterno">Alternate No.</label>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="orgalterno" id="orgalterno" value="{{ old('orgalterno') }}" minlength="10" maxlength="10" class="form-control project_box">
                                                 @error('orgalterno')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                       
                                
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgcountry">Country</label><span style="color:red;">*</span>
     
                                              <select name="orgcountry" id="orgcountry" class="form-control project_box">
                                                    <option value="">Please Select</option>
                                                    @foreach($CData as $result)
                                                    <option value="{{$result['countryid']}}">{{$result['countryname']}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('orgcountry')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgstate">State</label><span style="color:red;">*</span>
                                                <select name="orgstate" id="orgstate" class="form-control project_box statelist">
                                                    <option value="">Please Select</option>
                                                </select>
                                                 @error('orgstate')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgcity">City</label><span style="color:red;">*</span>

                                                <SELECT name="orgcity" id="orgcity" class="form-control project_box citylist">
                                                    <option value="">Please Select</option>
                                                    
                                                </SELECT>
                                                 @error('orgcity')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgcity">Pin Code <span style="color:red;">*</span></label>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="orgpincode" id="orgpincode" class="form-control project_box"  value="{{ old('orgpincode') }}" maxlength="6" >
                                                 @error('orgpincode')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                         <?php  $statuslist = DB::table('grc_status')->get();?>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgstatus">Status</label><span style="color:red;">*</span>
                                                <select name="orgstatus" id="orgstatus" class="form-control project_box">
                                                    <option value="">Select option</option>
                                                    @foreach($statuslist as $value)
                                                    <option value="{{$value->status_name}}">{{$value->status_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('orgstatus')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgaddress">Address</label><span style="color:red;">*</span>
                                                <textarea rows="4" name="orgaddress" id="orgaddress" maxlenght="255" class="form-control project_box">{{ old('orgaddress') }}</textarea>
                                            </div>
                                             @error('orgaddress')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                        </div>
                                         
                                          <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orglogo">Logo</label> <span style="color:red;">*</span>
                                                <input type="file" name="orglogo"  class="form-control project_box file_input" onchange="return ValidateFileUpload()" id="fileChooser">

                                             <img src="" id="blah" width="67px">
                                             @error('orglogo')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>

                                        </div>

                                        <div class="col-xs-12 col-sm-6"></div>

                                        <div class="col-xs-12 col-sm-12 text-center">
                                                <button type="button" data-toggle="modal" data-target="#exampleModalScrollable" class="previvew_btn preview" id="sameasdata" onclick="getInputValue();">Preview</button>
                                                <input type="submit" name="submit" value="Submit" class="submit_btn">
                                        </div>

                                        <!-- <div class="col-xs-12 col-sm-6">
                                            <div class="see_details">
                                                <p>Click <a href="org_details.html">here</a> to see project details.</p>
                                            </div>
                                        </div> -->
                                    </div>
                                </form> 
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
    </div>
    <div id="addproject" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel">Create a New Project</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <div class="form-group row">
                    <label for="example-text-input1" class="col-sm-4 col-form-label">Organization Name</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" value="" id="example-text-input2">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="example-text-input3" class="col-sm-4 col-form-label">Project ID</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" value="" id="example-text-input4">
                    </div>

                </div>
                <div class="form-group row">
                    <label for="example-text-input5" class="col-sm-4 col-form-label">Project Type</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" value="" id="example-text-input6">
                    </div>

                </div>

                <div class="form-group row">
                    <label for="example-text-input7" class="col-sm-4 col-form-label">Organization ID</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" value="Artisanal kale" id="example-text-input8">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-text-input9" class="col-sm-4 col-form-label">Status</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="text" value="" id="example-text-input10">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-text-input11" class="col-sm-4 col-form-label">Status</label>
                    <div class="col-sm-8">
                        <input class="form-control" type="mail" value="" id="example-text-input12">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary waves-effect">Create Project</button>
                <button type="button" class="btn btn-secondary waves-effect waves-light" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>
<!-- /.modal-content -->

<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
<div class="modal fade bd-example-modal-xl preview_form" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="preview_mode">
                    <div class="row">
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Organization Name</label>
                                <p id="previeworgname"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Organization Email</label>
                                <p id='previeworgemail'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>User Name</label>
                                <p id='previeworguname'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Mobile No.</label>
                                <p id='previeworgmobile'></p>
                            </div>
                        </div>
                        <!-- <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Phone No.</label>
                                <p id='previeworgphone'></p>
                            </div>
                        </div> -->
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Alternate No.</label>
                                <p id='previeworgaltno'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                               
                                <label>Country</label>
                                <p id='previeworgcountry'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>State</label>
                                <p id='previeworgstate'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>City</label>
                                <p id='previeworgcity'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Pin Code</label>
                                <p id='previeworgpincode'></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Status</label>
                                <p id='previeworgstatus'></p>
                            </div>
                        </div>
                        <!-- <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Logo</label>
                                <p id='previeworglogo'><img src="assets/images/logo.png" alt="" title=""></p>
                            </div>
                        </div> -->
                       <!--  <div class="col-xs-12 col-sm-12">
                            <div class="form-group">
                                <label>Project Description</label>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
</div>
<!-- /.modal-dialog -->
</div>
@stop