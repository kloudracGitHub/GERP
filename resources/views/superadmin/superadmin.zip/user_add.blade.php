  @extends('superadmin_layout')
   @section('content')
 <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add User</h4>
                            </div>
                            <div class="col-sm-6">
                                <h4 class="page-title project_super"></h4>
                            </div>
                        </div>
                    </div>
                </div>
                

                
                
                  @if(session::has('msg'))
                            
                                                       <div class="alert alert-warning alert-dismissible fade show" role="alert">
                              {{session::get('msg')}}
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>


                           @endif
                <div class="add_project_wrapper">
                    <div class="container-fluid">
                      
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/Users-add')}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="row">
                                 
                                        <!--<div class="col-xs-12 col-sm-6">
                                             @if(session('role') == 'admin' || session('role') == 'project_Manager')
                                            <div class="form-group">
                                                <?php $org_list = DB::table('grc_organization')->get();
                                                   // echo(session('org_id')); die('dgfsd');
                                                ?>
                                                <label for="fname">Organization Name</label>

                                                <select name="org_name" id="org_name" class="form-control project_box" disabled="true">
                                                    <option value="">Please Select...</option>
                                                    @foreach($org_list as $org)
                                                    <option value="{{$org->id}}" @if(session('org_id') == $org->id) selected @endif>{{$org->org_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('org_name')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                            @else
                                            <div class="form-group">
                                                <?php $org_list = DB::table('grc_organization')->get();?>
                                                <label for="fname">Organization Name</label>

                                                <select name="org_name" id="org_name"  class="form-control project_box">
                                                    <option value="">Please Select...</option>
                                                    @foreach($org_list as $org)
                                                    <option value="{{$org->id}}">{{$org->org_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('org_name')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                            @endif
                                        </div>
                                        @if(session('role') == 'admin' || session('role') == 'project_Manager')
                                        <div class="col-xs-12 col-sm-6">
                                            <?php $pro_list = DB::table('grc_project')->where('organization_id',session('org_id'))->get();?>
                                            <div class="form-group">
                                                <label for="fname">Project Name</label>
                                                <select name="pro_name" id="pro_name"  class="form-control project_box">
                                                    <option value=" ">Please Select...</option>
                                                    @foreach($pro_list as $pro)
                                                    <option value="{{$pro->id}}">{{$pro->project_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('pro_name')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>
                                        @else
                                        <div class="col-xs-12 col-sm-6">
                                            <?php $pro_list = DB::table('grc_project')->get();?>
                                            <div class="form-group">
                                                <label for="fname">Project Name</label>
                                                <select name="pro_name" id="pro_name" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    @foreach($pro_list as $pro)
                                                    <option value="{{$pro->id}}">{{$pro->project_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('pro_name')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>
                                        @endif
                                                -->

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="fname">First Name</label><span style="color:red">*</span>
                                                <input type="text" name="fname" id="fname" value="{{ old('fname') }}" maxlength="60" class="form-control project_box">
                                                 @error('fname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="fname">Middle Name</label>
                                                <input type="text" name="mname" id="mname" value="{{ old('mname') }}"  maxlength="60" class="form-control project_box">
                                                
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="lname">Last Name</label><span style="color:red">*</span>
                                                <input type="text" name="lname" id="lname" value="{{ old('lname') }}" maxlength="60" class="form-control project_box">
                                                 @error('lname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="fname">User Name</label><span style="color:red">*</span>
                                                <input type="text" name="uname" id="uname" value="{{ old('uname') }}" maxlength="60" class="form-control project_box">
                                                 @error('uname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="emailaddress">Email Address</label><span style="color:red">*</span>
                                                <input type="text" name="emailaddress" id="emailaddress" value="{{ old('emailaddress') }}" maxlength="60" class="form-control project_box">
                                                 @error('emailaddress')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="emailaddress">Alternet Email Address</label>
                                                <input type="text" name="alt_emailaddress" id="alt_emailaddress" value="{{ old('emailaddress') }}" maxlength="60" class="form-control project_box">
                                                
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="emailaddress">Role</label><span style="color:red">*</span>
                                                <select name="role" id="role"  class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                     @if(session('role') == 'superadmin')
                                                    <option value="admin">Admin</option>
                                                    <option value="project_Manager">Project Manager</option>
                                                    <option value="employee">User</option>
                                                    @else
                                                     <option value="project_Manager">Project Manager</option>
                                                    <option value="employee">User</option>
                                                    
                                                    @endif
                                                </select>
                                                 @error('role')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Mobile No.</label><span style="color:red">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="mobile" id="mobile" value="{{ old('mobile') }}" maxlength="10" class="form-control project_box">
                                            </div>
                                             @error('mobile')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Alternate No.</label>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="alternate" id="alternate"  value="{{ old('alternate') }}" maxlength="10" class="form-control project_box">
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Pancard No.</label><span style="color:red">*</span>
                                                <input type="text" name="pancard" id="pancard"  value="{{ old('pancard') }}" maxlength="10" class="form-control project_box">
                                                 @error('pancard')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Aadhaar Card No.</label><span style="color:red">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="adhaar" id="adhaar"  value="{{ old('adhaar') }}" maxlength="12" class="form-control project_box">
                                                 @error('adhaar')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Designation</label>
                                                <input type="text" name="designation" id="designation" value="{{ old('designation') }}" maxlength="60" class="form-control project_box">
                                               
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">DOB</label><span style="color:red">*</span>
                                                <input type="text" name="dob" id="dob" value="{{ old('dob') }}" placeholder="dd/mm/yyyy" class="dateTxt form-control project_box">
                                                 @error('dob')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Gender</label><span style="color:red">*</span>
                                                <select name="gender" id="gender" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Male">Male</option>
                                                </select>
                                                 @error('gender')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">Address</label><span style="color:red">*</span>
                                                <input type="text" name="address" id="address" value="{{ old('address') }}" maxlength="200"  class="form-control project_box">
                                                 @error('address')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <?php $con_list = DB::table('grc_superadmin_country_list')->join('alm_countries','grc_superadmin_country_list.country_id','=','alm_countries.id')->
                                            get();?>
                                            <div class="form-group">
                                                <label for="phonenumber">Country</label><span style="color:red">*</span>
                                                <select name="country" id="empcountry" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    @foreach($con_list as $val)
                                                    <option value="{{$val->id}}">{{$val->name}}</option>
                                                    @endforeach
                                                </select>

                                                 @error('country')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">State</label><span style="color:red">*</span>
                                                 <select name="state" id="empstate" class="form-control project_box statelist">
                                                     
                                                        <option value="">Select Option</option>
                                                 </select>

                                                  @error('state')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                                
                                            </div>
                                        </div>

                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">City</label><span style="color:red">*</span>
                                                 <select name="city" id="city" class="form-control project_box citylist" >
                                                     <option value="">Select Option</option>
                                                 </select>
                                                @error('city')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="landmark">Landmark</label>
                                                <input type="text" name="landmark" id="landmark" value="{{ old('landmark') }}" maxlength="200" class="form-control project_box">
                                                 
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="pincode">Pin Code</label><span style="color:red">*</span>
                                                <input type="number" name="pincode" id="pincode" value="{{ old('pincode') }}" maxlength="10" class="form-control project_box">
                                                 @error('pincode')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="profile_image">Profile Image</label><span style="color:red">*</span>
                                                <input type="file" name="profileimage"   onchange="return ValidateFileUpload()" id="fileChooser">

                                             <img src="" id="blah" width="67px">
                                             @error('profileimage')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>

                                        </div>

                                        <div class="col-xs-12 col-sm-12 text-center">
                                                <button type="button" data-toggle="modal" data-target="#exampleModalScrollable" class="previvew_btn" onclick="getuserValue();">Preview</button>
                                                <input type="submit" name="submit" value="Submit" class="submit_btn">
                                        </div>

                                    </div>
                                </form> 
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->
    </div>

<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
<div class="modal fade bd-example-modal-xl" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="preview_mode">
                    <div class="row">
                 
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>First Name</label>
                                <p id="userfname"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Last Name</label>
                                <p id="userlname"></p>
                            </div>
                        </div>
                         <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>User Name</label>
                                <p id="username"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Email Address</label>
                                <p id="useremail"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Mobile No.</label>
                                <p id="usermobile"></p>
                            </div>
                        </div>
                        
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> Role.</label>
                                <p id="viewrole"></p>
                            </div>
                        </div>
                       
                             <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> Alternate No.</label>
                                <p id="altmobile"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Pancard No.</label>
                                <p id="pencard"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> Aadhaar Card No.</label>
                                <p id="addhar"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> Designation.</label>
                                <p id="viewdesignation"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> DOB.</label>
                                <p id="viewdob"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label> Gender.</label>
                                <p id="viewgender"></p>
                            </div>
                        </div>
                        
                              <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Address.</label>
                                <p id="viewaddress"></p>
                            </div>
                        </div>
                        
                         <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Country.</label>
                                <p id="country"></p>
                            </div>
                        </div>
                        
                        
                         <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>State.</label>
                                <p id="state"></p>
                            </div>
                        </div>
                        
                         <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>City.</label>
                                <p id="viewcity"></p>
                            </div>
                        </div>
                        
                 
                        
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Pin Code</label>
                                <p id="userpincode"></p>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Landmark</label>
                                <p id="userlandmark"></p>
                            </div>
                        </div>
                        
                           <div class="col-xs-12 col-sm-3">
                            <div class="form-group">
                                <label>Image.</label>
                                <p id="imgsrc"></p>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!------------------------------------------>
<!-------------- Preview Modal ------------->
<!------------------------------------------>
@stop
 @section('extra_js')
   
   <script>
$(function(){$('.dateTxt').datepicker(); }); 
</script>
   
   @stop
