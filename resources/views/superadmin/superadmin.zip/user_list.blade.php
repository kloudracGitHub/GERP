   @extends('superadmin_layout')
   @section('content')
   <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Users</h4>
                            </div>
                        </div>
                    </div>
                    
                    @if(session::has('msg'))
                    
                    <div class="alert alert-{{session::get('alert')??'primary'}} alert-dismissible fade show" role="alert">
  {{session::get('msg')}}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
                    
                    @endif

                    <div class="add_project_name">
                        <div class="row">
                            <?php $count = DB::table('grc_organization')->where('id',session('org_id'))->first();?>
                            <div class="col-xs-12 col-sm-12 text-right">
                                @if(session('role') == 'admin' || session('role') == 'project_Manager' || session('role') == 'employee')
                                <h2>{{$count->org_name??0}}</h2>
                                @else
                                <h2>GRC</h2>
                                @endif
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body table-responsive">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S. No.</th>
                                                <th>Emp id</th>
                                                <th>First name</th>
                                                <th>Last name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Action</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = ($user_list->currentpage()-1)* $user_list->perpage() + 1;?>
                                            @foreach($user_list as  $usera)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td>{{$usera->employee_id}}</td>
                                                <td>{{$usera->first_name}}</td>
                                                <td>{{$usera->last_name}}</td>
                                                <td>{{$usera->email}}</td>
                                                <td>{{$usera->mobile_no}}</td>
                                                <td>
                                                    <label class="switch">
                                                         @if($usera->status==1)
                                                        <a  onclick="return confirm('Are you sure you want to Activa ?');" href="{{URL::to('/Users-status/'.$usera->id)}}"><input type="checkbox" name="" checked=""><span class="slider round"></span></a>
                                                        @else
                                                       <a  onclick="return confirm('Are you sure you want to DeActiva ?');" href="{{URL::to('/Users-status/'.$usera->id)}}"><input type="checkbox" name=""><span class="slider round"></span></a>
                                                        @endif

                                                    </label>
                                                </td>
                                                <td><a href="{{URL::to('/Users-view/'.$usera->id)}}" class="project_det_page"><img src="{{URL::to('assets/images/eye.png')}}" alt="" title=""></a></td>
                                            </tr>
                                            @endforeach

                                             {{ $user_list->links() }}
                                        </tbody>
                                    </table>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="add_project_new">
                                                <a href="{{URL::to('/Users-add')}}">
                                                    Add User
                                                    <span>+</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        @stop