@extends('superadmin_layout')
@section('content')
<div class="content-page">
   <!-- Start content -->
   <div class="content p-0">
      <div class="container-fluid">
         <div class="col-xs-8">
            @if(Session::has('alert-success'))
            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('alert-success') }}</p>
            @endif
            @if ($message = Session::get('warn-task-detail'))
            <div class="alert alert-danger alert-block">
               <strong>{{ $message }}</strong>
            </div>
            @endif
         </div>
         <div class="page-title-box">
            <div class="row align-items-center bredcrum-style">
               <div class="col-sm-6">
                  <h4 class="page-title">Task Details</h4>
               </div>
            </div>
         </div>
      </div>
      <div class="tasks_details">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="compliance_condition">
                     <div class="row">
                        <div class="col-xs-12 col-sm-7">
                           <h3>
                              Condition Details - {{$taskData[0]['condition_no']}}
            
                              @if($taskData[0]['task_status'] != 'Completed')
                              <a href="{{URL::to('/Task-edit-detail/'.$id)}}" class="edit_task">Edit</a>
                              @endif
                           </h3>
                        </div>
                        <div class="col-sm-5">
                           <h4 class="page-title project_super">{{ucwords($projectshow->project_name??'')}}</h4>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xs-12 col-sm-12">
                  <div class="task_header">
                     <div class="row">
                        <div class="col-xs-12 col-sm-6">
                           <h5>Task Details</h5>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <h5>Task Last Date</h5>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <h5>Status</h5>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <h5>Probability</h5>
                        </div>
                     </div>
                  </div>
                  <div class="task_body">
                     <div class="row">
                        <div class="col-xs-12 col-sm-6">
                           <p>{{$taskData[0]['task_name']}}</p>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <p>{{date('d-m-Y',strtotime($taskData[0]['end_date']))}}</p>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <p>{{$taskData[0]['task_status']}}</p>
                        </div>
                        <div class="col-xs-12 col-sm-2">
                           <p>{{$taskData[0]['Probability']}}</p>
                        </div>
                        <!-- <div class="col-xs-12 col-sm-1">
                           <a href="#" class="edit_task">Edit</a>
                           </div> -->
                     </div>
                     <div class="row">
                                 <div class="col-xs-12 col-sm-6">
                                    <div class="task_history">
                                       <h4>
                                          <a data-toggle="collapse" href="#figureAtSite" role="button" aria-expanded="true" aria-controls="multiCollapseExample1">
                                          Figure at site
                                          <span class="plus_icon">+</span>
                                          <span class="minus_icon">-</span>
                                          </a>
                                       </h4>
                                       <div class="row">
                                          <div class="col">
                                             <div class="collapse multi-collapse show" id="figureAtSite">
                                                <div class="card card-body task_history_details">
                                                   <div class="figure_actual_site">
                                                       @foreach($taskdoc as $td)
                                                     {!!$td['figure_at_site']!!}
                                                     @endforeach
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-xs-12 col-sm-6">
                                    <div class="task_history">
                                       <h4>
                                          <a data-toggle="collapse" href="#actualAtSite" role="button" aria-expanded="true" aria-controls="multiCollapseExample1">
                                          Actual at site
                                          <span class="plus_icon">+</span>
                                          <span class="minus_icon">-</span>
                                          </a>
                                       </h4>
                                       <div class="row">
                                          <div class="col">
                                             <div class="collapse multi-collapse show" id="actualAtSite">
                                                <div class="card card-body task_history_details">
                                                   <div class="figure_actual_site">
                                                       @foreach($taskdoc as $td)
                                                     {!!$td['actual_at_site']!!}
                                                     @endforeach
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                     <div class="row">
                        <div class="col-xs-12 col-sm-12">
                           <div class="task_body_details">
                              <div class="hint_details">
                                 <h3>Hints <a href="javscript:void(0);"><img src="{{URL::to('assets/images/eye.png')}}" alt="" title=""></a></h3>
                                 <div class="hint_details_body">
                                    <ul>
                                       <li>The project proponent shall maintain the distance</li>
                                       <li>The project proponent.</li>
                                       <li>The project proponent shall maintain the distance lorem ipsum</li>
                                       <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>
                                       <li>The project proponent shall maintain the distance</li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="remarks_upload_wrapper">
                        <!-- <h5>Remarks</h5> -->
                        <div class="row">
                           
                           <div class="col-xs-12 col-sm-12">
                              <div class="task_history">
                                 <h4>
                                    <a data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="true" aria-controls="multiCollapseExample1">
                                    Task Report
                                    <span class="plus_icon">+</span>
                                    <span class="minus_icon">-</span>
                                    </a>
                                 </h4>
                                 <div class="">
                                    <div class="row">
                                       <div class="col">
                                          <div class="collapse multi-collapse show" id="multiCollapseExample1">
                                             <div class="card card-body task_history_details">
                                                <div class="task_report">
                                                   <!-- <h2>Task Report</h2> -->
                                                   <div class="table-responsive">
                                                      <table class="table table-bordered table-striped">
                                                         <thead>
                                                            <tr>
                                                               <th scope="col" style="width: 13%;">Date</th>
                                                               <th scope="col">Remarks</th>
                                                               <th scope="col">Status</th>
                                                               <th scope="col">Probability</th>
                                                               <th scope="col" style="width: 15%;">Attachment</th>
                                                            </tr>
                                                         </thead>
                                                         
                                                         <tbody>
                                                            @foreach($taskdoc as $td)
                                                            <?php $date = $td['cdate'];
                                                     $finalDate = explode(' ',$date);
                                                     $data = $finalDate[0];
                                                    $Dates = date("d-m-Y", strtotime($data));
                                                    
                                                    $file = explode('|',$td['document']);
                                                    ?>
                                                            <tr>
                                                               <td scope="row">{{$Dates}}</td>
                                                               <td>{{$td['task_remark']}}</td>
                                                               <td>{{$td['task_status']}}</td>
                                                               <td>{{$td['Probability']}}</td>
                                                               <td>
                                                                    @if(!empty($td['document']))
                                                                 @foreach($file as $files)
                                                                 {{$files}}
                                             <a href="{{URL::to('/Task-documentdownload/')}}/{{$files}}" target="_blank">download</a>
                                              @endforeach
                                              @endif
                                           
                                                               </td>
                                                            </tr>
                                                           @endforeach
                                                      @if(count($taskdoc)==0)
                    <tr>
                           <td colspan = '8' align = 'center'> <b> No report found</b>
                           </td>
                        </tr>
                @endif
                                                         </tbody>
                                                      </table>
                                                   </div>
                                                </div>
                                                @if(count($taskdoc)>0)
                                              <a href="#" class="remarks_hist" data-toggle="modal" data-target=".bd-example-task-history">View More</a>
                                              @endif
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!--<div class="col-xs-12 col-sm-12">-->
                           <!--   <div class="submit_task_details">-->
                           <!--      <input type="submit" name="submittask" class="submit_task" value="Save">-->
                           <!--   </div>-->
                           <!--</div>-->
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- end row -->
         </div>
      </div>
      <!-- container-fluid -->
   </div>
   <!-- content -->
   <!-- <footer class="footer">© 2019 GRC </footer> -->
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>
    <div class="modal fade bd-example-task-history" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="task_report">
                     <h2>Task Report</h2>
                     <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                           <thead>
                              <tr>
                                 <th scope="col" style="width: 13%;">Date</th>
                                 <th scope="col">Remarks</th>
                                 <th scope="col">Status</th>
                                 <th scope="col">Probability</th>
                                 <th scope="col" style="width: 15%;">Attachment</th>
                              </tr>
                           </thead>
                           <tbody>
                             @foreach($taskdoc as $td)
                                                            <?php $date = $td['cdate'];
                                                     $finalDate = explode(' ',$date);
                                                     $data = $finalDate[0];
                                                     $file = explode('|',$td['document']);
                                                    $Dates = date("d-m-Y", strtotime($data));?>
                                                            <tr>
                                                               <td scope="row">{{$Dates}}</td>
                                                               <td>{{$td['task_remark']}}</td>
                                                               <td>{{$td['task_status']}}</td>
                                                               <td>{{$td['Probability']}}</td>
                                                               <td>
                                                                     @foreach($file as $files)
                                                                 {{$files}}
      <a href="{{URL::to('/Task-documentdownload/')}}/{{$files}}" target="_blank">download</a>
      @endforeach
                                                               </td>
                                                            </tr>
                                                           @endforeach
                                                      @if(count($taskdoc)==0)
                    <tr>
                           <td colspan = '8' align = 'center'> <b> No Remark Found</b>
                           </td>
                        </tr>
                @endif
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
@stop