  @extends('superadmin_layout')
   @section('content') 
  <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style m-b-20 p-10 new_breadcrumb_design">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Circular</h4>
                            </div>
                        </div>
                    </div>
                    
                        @if (session::has('msg'))
                   <div class="alert alert-primary">
                  {{session::get('msg')}}
                   </div>
                   @endif
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">    
                            <div class="add_circular_wrapper">
                                <div class="add_circular_icon">
                                   
                                </div>
                               <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/circular')}}"  enctype="multipart/form-data">   
                                  <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="inner_circular_wrapper">
                                        <div class="row">    
                                            <div class="col-12 col-sm-12 col-md-6">
                                                <div class="form-group">
                                                    <textarea name="addCircular" title="addCircular" maxlenght="500" class="form-control" placeholder="Enter Circular"></textarea>
                                                  
                                                   
                                                </div>
                                            </div>


                                            <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="profile_image">Files</label>
                                                <input type="file" name="circularimage" >

                                          
                                                                                         </div>

                                        </div>

                                        </div>
                                    </div>

                                    <div class="submit_circular">
                                        <input type="submit" name="submitCircular" maxlenght="500" id="submitCircular" class="circular_btn" value="Add Circular">
                                    </div>
                                </form>
                                </div>
                                 <div class="table-responsive">
                                        <table class="table table-bordered" style="margin-top: 10px;">
                                            <thead>
                                                <tr>
                                                    <th scope="col">S No.</th>
                                                    <th scope="col">Circulars</th>
                                                    <th scope="col">Attachment</th>
                                                    <th scope="col">Created Date</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1?>
                                                @foreach($updateData as $result)
                                                <tr>
                                                    <td>{{$i++}}</td>
                                                <td>{{$result->circular_name}}</td>
                                                <td>
                                                @if(!empty($result->attachment))
                                                <a href="{{URL::to('/attachement')}}/{{$result->attachment}}"> Downlond</a>
                                               @endif
                                                </td>
                                                 <?php $date = $result->created_date;
                                                     $finalDate = explode(' ',$date);
                                                     $data = $finalDate[0];
                                                    $Dates = date("d-m-Y", strtotime($data));?>
                                                <td>{{$Dates}}</td>
                                                 <td>
                                                    <a href="{{URL::to('/circular-delete/'.$result->id)}}"><i class="mdi mdi-delete text-danger" data-toggle="modal" onclick="return confirm('Are you sure you want to delete');"
                                                               data-target="#deletemp" title="Delete"></i></a>
                                                </td>
                                                </tr>
                                               @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content -->
        </div>
        @stop