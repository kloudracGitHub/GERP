 @extends('superadmin_layout')
   @section('content')
 <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Organization</h4>
                            </div>
                        </div>
                    </div>
                   @if(session::has('msg'))
                   
                   <div class="alert alert-warning alert-dismissible fade show" role="alert">
                  {{session::get('msg')}}
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                   
                   @endif
                   
                    @if(session::has('status'))

                    <div class="alert alert-{{session::get('alert')}} alert-dismissible fade show" role="alert">
 {{session::get('status')}}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
                    @endif
                    <div class="add_project_name">
                        <div class="row">
                      

                            <!-- <div class="col-xs-12 col-sm-5">
                                <div class="state_dist">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="state_drop">
                                                <select>
                                                    <option value="">Please Select State</option>
                                                    <option value="Delhi">Delhi</option>
                                                    <option value="Mumbai">Mumbai</option>
                                                    <option value="Chennai">Chennai</option>
                                                    <option value="Kolkata">Kolkata</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="dist_drop">
                                                <select>
                                                    <option value="">Please Select District</option>
                                                    <option value="Delhi">Delhi</option>
                                                    <option value="Noida">Noida</option>
                                                    <option value="Ghaziabad">Ghaziabad</option>
                                                    <option value="Greater Noida">Greater Noida</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body table-responsive">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S. No.</th>
                                                <th>Organization Id</th>
                                                <th>Organization Name</th>
                                                <th>Organization Email</th>
                                                <th>Country</th>
                                                <th>Status</th>
                                                <th>Created Date</th>
                                                <th>Action</th>
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $key = ($Data->currentpage()-1)* $Data->perpage() + 1;?>
                                            @foreach($Data as $result)
                                            <tr>
                                                <td>{{$key++}}</td>
                                                <td>{{$result->org_unique_id}}</td>
                                                <td>{{$result->org_name}}</td>
                                                <td>{{$result->org_email}}</td>
                                                <td>{{$result->name}}</td>
                                                <td>{{$result->org_status}}</td>
                                                <?php $date = $result->created_date;
                                                     $finalDate = explode(' ',$date);
                                                     $data = $finalDate[0];
                                                    $Dates = date("d-m-Y", strtotime($data));?>
                                                <td>{{$Dates}}</td>
                                                <td>

                                                    <label class="switch">
                                                        @if($result->status==1)
                                                        <a onclick="return confirm('Are you sure you want to Activa?');" href="{{URL::to('/Organization-status/'.$result->organizationid)}}"><input type="checkbox" name="" checked=""><span class="slider round"></span></a>
                                                        @else
                                                       <a onclick="return confirm('Are you sure you want to DeActiva?');" href="{{URL::to('/Organization-status/'.$result->organizationid)}}"><input type="checkbox" name=""><span class="slider round"></span></a>
                                                        @endif
                                                        
                                                    </label>
                                                    </td>
                                                    <td>
                                                    <a href="{{URL::to('/Organization-view/'.$result->organizationid)}}"><i class="fas fa-eye"></i></a> 
                                                </td>
                                            </tr>
                                             @endforeach

                                              {{ $Data->links() }}
                                             @if(count($Data) == 0)
                                             <tr>
                                             <td colspan='9' align='center'> <b> No Data Found</b>
                                             </td>
                                             </tr>
                                             @endif

                                             
                                        </tbody>
                                    </table>
                                    <div class="add_project_new">
                                        <a href="{{URL::to('/Organization-add')}}">
                                            Add Organization
                                            <span>+</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->

                        <div class="col-xs-12">

                        </div>
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        @stop