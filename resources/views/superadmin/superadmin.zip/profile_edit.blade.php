@extends('superadmin_layout')
   @section('content')
        <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="col-xs-8">
                        @if(Session::has('msg'))
                        <p class="alert {{ Session::get('alert') }}"></p>
                        @endif
                        @if ($message = Session::get('msg'))
                        <div class="alert alert-{{ Session::get('alert') }} alert-block">
                          <strong>{{ $message }}</strong>
                        </div>
                        @endif
                </div>
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h3 class="page-title my_profile">Update My Profile </h3>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                </div>
                
                <!-- container-fluid -->
                <div class="profile_edit_wrapper add_project_wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="profile_save_wrapper">
                                    <h2>Oppo</h2>
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-8">
                                            <ul>
                                                <li>
                                                    <div class="edit_img_wrapper">
                                                        @if(!empty($userprofile->photo))
                                    <img src="{{URL::to('/uploads_profileimg/'.$userprofile->photo)}}" alt="user" class="rounded-circle">
                                    @else
                                       <img src="{{URL::to('assets/download.png')}}" alt="user" class="rounded-circle">
                                    @endif
                                                       <!--  <img src="{{URL::to('/uploads_profileimg/'.$userprofile->photo)}}" alt="" title=""> -->
                                                        <!-- <input type="file" name="imageupload" id="imageupload"> -->
                                                        
                                                    </div>
                                                </li>
                                                <li>
                                                    <h5>{{$userprofile->first_name}}  {{$userprofile->last_name}}</h5>
                                                    <p>{{$userprofile->email}}</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="profile_edit_inside">
                                    <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/Profile-edit/'.$id)}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="empid">EMP ID</label>
                                                    <input type="text" value="{{$userprofile->employee_id}}" name="empid" id="empid" maxlength="20" class="form-control project_box" disabled="true">
                                                </div>
                                            </div>
                                            
                                     
                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="fname">First Name</label>
                                                    <input type="text" value="{{$userprofile->first_name}}" name="fname" id="fname" maxlength="20" class="form-control project_box">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="lname">Last Name</label>
                                                    <input type="text" value="{{$userprofile->last_name}}" name="lname" id="lname" maxlength="20" class="form-control project_box">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="emailaddress">Email Address</label>
                                                    <input type="text" value="{{$userprofile->email}}" name="emailaddress" id="emailaddress" class="form-control project_box" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="phonenumber">Phone No.</label>
                                                    <input type="number" value="{{$userprofile->mobile_no}}" name="phonenumber" maxlength="10" id="phonenumber" class="form-control project_box">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="dob">Date Of Birth</label>
                                                    <input type="text" value="{{$userprofile->dob}}" name="dob" id="dob" placeholder="dd/mm/yyyy" class="dateTxt form-control project_box">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="landmark">Landmark</label>
                                                    <input type="text" value="{{$userprofile->landmark}}" name="landmark" maxlength="60" id="landmark" class="form-control project_box">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="gender">Gender</label>
                                                    <select name="gender" id="gender" class="form-control project_box">
                                                        <option value="Male" @if($userprofile->gender == "Male") selected @endif>Male</option>
                                                        <option value="Female" @if($userprofile->gender == "Female") selected @endif>Female</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="mStatus">Marital Status</label>
                                                    <select name="mStatus" id="mStatus" class="form-control project_box">
                                                        <option value="Married">Married</option>
                                                        <option value="Unmarried" selected="selected">Unmarried</option>
                                                    </select>
                                                </div>
                                            </div> -->

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="nationality">Nationality</label>
                                                    <select name="nationality" id="nationality" class="form-control project_box">
                                                        <option value="Indian" selected="selected">Indian</option>
                                                       
                                                    </select>
                                                </div>
                                            </div>

                                            <!--<div class="col-xs-12 col-sm-6">-->
                                            <!--    <div class="form-group">-->
                                            <!--        <label for="country">Country</label>-->
                                            <!--        <select name="country"  class="form-control project_box">-->
                                            <!--            @foreach($usercon as $con)-->
                                            <!--            <option value="{{$con->id}}"    @if($userprofile->country == $con->id) selected @endif>{{$con->name}}</option>-->
                                            <!--           @endforeach-->
                                            <!--        </select>-->
                                            <!--    </div>-->
                                            <!--</div>-->

                                            <!--<div class="col-xs-12 col-sm-6">-->
                                            <!--    <div class="form-group">-->
                                            <!--        <label for="prcity">City</label>-->
                                            <!--        <select name="city"  class="form-control project_box">-->
                                            <!--        @foreach($usercit as $cityy)-->
                                            <!--            <option value="{{$cityy->id}}"    @if($userprofile->city == $cityy->id) selected @endif>{{$cityy->name}}</option>-->
                                            <!--           @endforeach-->
                                            <!--       </select>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            
                                                     <div class="col-xs-12 col-sm-6">
                                            <?php $con_list = DB::table('grc_superadmin_country_list')->join('alm_countries','grc_superadmin_country_list.country_id','=','alm_countries.id')->
                                            get();?>
                                            <div class="form-group">
                                                <label for="phonenumber">Country</label>
                                                <select name="country" id="empcountry" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    @foreach($con_list as $val)
                                                    <option value="{{$val->id}}"  @if($userprofile->country == $val->id) selected @endif>{{$val->name}}</option>
                                                    @endforeach
                                                </select>

                                                 @error('country')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>
                                          <?php 
                                          $state = DB::table('alm_states')->where('country_id',$userprofile->country)->get();
                                         
                                          
                                          ?>
                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">State</label>
                                                 <select name="state" id="empstate" class="form-control project_box statelist">
                                                     
                                                        <option value="">Select Option</option>
                                                         @foreach($state as $val)
                                                    <option value="{{$val->id}}"  @if($userprofile->state == $val->id) selected @endif>{{$val->name}}</option>
                                                    @endforeach
                                                 </select>

                                                  @error('state')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                                
                                            </div>
                                        </div>
 
                                          <?php 
                                          $city = DB::table('alm_cities')->where('state_id',$userprofile->state)->get();
                                        // dd($userprofile->state);
                                          
                                          ?>
    
                                         <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="phonenumber">City</label>
                                                 <select name="city" id="city" class="form-control project_box citylist" >
                                                     <option value="">Select Option</option>
                                                     @foreach($city as $val)
                                                    <option value="{{$val->id}}"  @if($userprofile->city == $val->id) selected @endif>{{$val->name}}</option>
                                                    @endforeach
                                                 </select>
                                                @error('city')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                            <!-- <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="prregion">Region</label>
                                                    <input type="text" value="Uttar Pradesh" name="prregion" id="prregion" class="form-control project_box">
                                                </div>
                                            </div> -->

                                            <div class="col-xs-12 col-sm-6">
                                                <div class="form-group">
                                                    <label for="pincode">Pin Code</label>
                                                    <input type="number" value="{{$userprofile->pincode}}" name="pincode" id="pincode" class="form-control project_box">
                                                </div>
                                            </div>
                                              <div class="col-xs-12 col-sm-6">
                                                <div class="form-group m-t-30">
                                                    <label for="pincode">Chnage Profile Pic </label>
                                                    <input type="file" name="profilepic" onchange="return ValidateFileUpload()" id="fileChooser">
                                                     <img src="" id="blah" width="67px">
                                                </div>
                                            </div>

                                            <div class="col-xs-12 col-sm-12">
                                                <div class="form-group text-center">
                                                    <input type="submit" name="submit" value="Submit" class="submit_btn">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- content -->
        </div>
@stop
@section('extra_js')
   
   <script>
$(function(){$('.dateTxt').datepicker(); }); 
</script>
   
   @stop