@extends('superadmin_layout')
   @section('content')
<div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                 
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Projects</h4>
                            </div>
                        </div>
                    </div>
                      @if(session::has('msg'))

                   <div class="alert alert-success">
                        {{session::get('msg')}}
                       </div>

                   @endif
                   
                     @if(session::has('status'))

                    <div class="alert alert-{{session::get('alert')}} alert-dismissible fade show" role="alert">
 {{session::get('status')}}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
                    @endif
                    <div class="add_project_name">
                        <div class="row">
                            <div class="col-xs-12 col-sm-3">
                               <!--  <h2>Supertech</h2> -->
                                <div class="advance_setting">
                                    <?php
                                    if(isset($_GET['projectid']) || isset($_GET['projectname']) || isset($_GET['projecttype']) || isset($_GET['projectstatus'])){
                                    ?>
                                        <a href="{{URL::to('Project-list')}}"><p><img src="assets/images/left_arrow.png"> Back</p></a>
                                        
                                        <?php
                                        }
                                        ?>
                                    </div>
                            </div>

                            <div class="col-xs-12 col-sm-9">
                                <div class="state_dist">
                                    <div class="advance_setting">
                                        <p><img src="assets/images/left_arrow.png"> Advance Search</p>
                                    </div>
                                    <form >
                                       
                                        <div class="state_dist_wrapper">
                                            <div class="close_popup">
                                                <img src="assets/images/close_icon.png" alt="" title="">
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <input type="text" name="projectid" id="projectid" class="state_drop"  placeholder="Project Id">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <input type="text" name="projectname" id="projectname" class="dist_drop" placeholder="Project Name">
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <div class="type_drop">
                                                            <select  name="projecttype">
                                                                <option value="">Project Type</option>
                                                                <option value="Housing Society">Housing Property</option>
                                                                <option value="Industrial Society">Industrial Society</option>
                                                                <option value="Residential Society">Residential Society</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-6">
                                                    <div class="form-group">
                                                        <div class="type_drop">
                                                            <select name="projectstatus">
                                                                <option value="">Project Status</option>
                                                                <option value="New">New</option>
                                                                <option value="Running">Running</option>
                                                                <option value="On Hold">On Hold</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-xs-12 col-sm-12">
                                                    <div class="form-group">
                                                        <input type="submit" name="search" value="Search" class="search_submit">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- end row -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body table-responsive">
                                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>S. No.</th>
                                                <th>Project Id</th>
                                                <th>Project Name</th>
                                                <th>Type</th>
                                                <th>Stage</th>
                                                <th>Status</th>
                                                <th>Created Date</th>
                                                @if(session('role') == 'employee')

                                                @else
                                                <th>Action</th>
                                                @endif
                                                <th>View</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                             <?php $i = ($projectlist->currentpage()-1)* $projectlist->perpage() + 1;?>
                                                   
                                            @foreach($projectlist as $result)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                @if(session('role') == 'employee')
                                                  <td>{{$result->project_id}}</td>
                                                @else
                                                  <td class="text_ellipses"><a href="{{URL::to('/Project-detail/'.$result->id)}}">{{$result->project_id}}</a></td>
                                                @endif
                                                <td class="text_ellipses">{{$result->project_name}}</td>
                                                <td>{{$result->project_type}}</td>
                                                <td>{{$result->project_stage}}</td>
                                                <td class="active-text">{{$result->project_status}}</td>
                                                <?php $date = $result->created_date;
                                                     $finalDate = explode(' ',$date);
                                                     $data = $finalDate[0];
                                                    $Dates = date("d-m-Y", strtotime($data));
                                                    ?>
                                                <td>{{$Dates}}</td>
                                                @if(session('role') == 'employee')

                                                @else
                                                <td>
                                                    <label class="switch">
                                                         @if($result->status==1)
                                                        <a  onclick="return confirm('Are you sure you want to Activa ?');" href="{{URL::to('/Project-status/'.$result->id)}}"><input type="checkbox" name="" checked=""><span class="slider round"></span></a>
                                                        @else
                                                       <a  onclick="return confirm('Are you sure you want to DeActiva ?');" href="{{URL::to('/Project-status/'.$result->id)}}"><input type="checkbox" name=""><span class="slider round"></span></a>
                                                        @endif

                                                    </label>
                                                </td>
                                                @endif
                                                    <td>
                                                    <a href="{{URL::to('/Project-view/'.$result->id)}}" class="project_det_page"><img src="{{URL::to('assets/images/eye.png')}}" alt="" title=""></a>

                                                     <a href="{{URL::to('/Project-edit/'.$result->id)}}" class="project_det_page"><i class="fas fa-edit"></i>
</a>
                                                    @if(session('admin') == 'admin' || session('admin') == 'superadmin')
                                                     <a onclick="return confirm('Are you sure you want to Remove?');" href="{{URL::to('/deleteproject/'.$result->id)}}" class="project_det_page"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                                      @endif
                                                </td>

                                            </tr>
                                           @endforeach

                                           @if(count($projectlist) == 0)
                                           <tr>
                                            <td colspan="9">Record Not Found</td>
                                          <tr>
                                           @endif

                                            {{ $projectlist->links() }}

                                        </tbody>
                                    </table>
                                    <div class="row">
                                        @if((session('role') == 'employee') || (session('role') == 'project_Manager'))

                                            

                                                @else
                                        <div class="col-xs-12 col-sm-6">
                                            <div class="add_project_new">
                                                <a href="{{URL::to('/Project-add')}}">
                                                    Add Project
                                                    <span>+</span>
                                                </a>
                                            </div>
                                        </div>
                                        @endif
                                     <!--  <div class="col-xs-12 col-sm-6">
                                            <div class="see_details">
                                                <p>Click <a href="project_details.html">here</a> to see project details.</p>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->

                        <div class="col-xs-12">

                        </div>
                    </div>
                    <!-- end row -->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
        @stop