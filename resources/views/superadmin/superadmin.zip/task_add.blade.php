 @extends('superadmin_layout')
   @section('content')
  <div class="content-page">
            <!-- Start content -->
            <div class="content p-0">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row align-items-center bredcrum-style">
                            <div class="col-sm-6">
                                <h4 class="page-title">Add Tasks</h4>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
               @if(session::has('task-war'))
               
               <div class="alert alert-danger alert-dismissible fade show" role="alert">
  {{session::get('task-war')}}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
               
               @endif
               
                <div class="add_project_wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12">
                               <form class="court-info-form"  role="form" method="POST" action="{{URL::to('/Task-add')}}"  enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="row">
                                        <!-- <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="orgId">Organization Id</label>
                                                <input type="text" name="orgId" id="orgId" value="GRC-001" class="form-control project_box" disabled="true">
                                            </div>
                                        </div> -->
                                      <?php $proname = DB::table('grc_project');
                                        if(session('role') !='superadmin'){
                                            $proname->where('organization_id','=',session('org_id'));
                                        }
                                        

                                         $project= $proname->where('status', 1)->get(); 

                                   
                                         
                                        ?>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectId">Project Name</label><span style="color:red;">*</span>
                                                <select name="projectId" id="projectId"  class="form-control project_box">
                                                <option value="">Select Option</option>
                                                 @foreach($project as $pro)
                                                 <option value="{{$pro->id}}">{{$pro->project_name}}</option>
                                                 @endforeach
                                                 </select>
                                                  @error('projectId')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                               
                                            </div>
                                        </div>


                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="taskname">Task Name</label><span style="color:red;">*</span>
                                                <input type="text" name="taskname" value="{{ old('taskname') }}" id="taskname" maxlength="60" class="form-control project_box">
                                                 @error('taskname')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="projectstate">State</label><span style="color:red;">*</span>
                                                <select name="projectstate" id="projectstate" class="form-control project_box">
                                                     <option value="">Select Option</option>
                                                 @foreach($statelist as $state)
                                                 <option value="{{$state->stateid}}">{{$state->name}}</option>
                                                 @endforeach
                                                 </select>
                                                  @error('projectstate')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="category">Category</label><span style="color:red;">*</span>
                                                <select name="category" id="category" class="form-control project_box">
                                                    <option value="">Select Option</option>
                                                    <option value="Generic">Generic</option>
                                                    <option value="Specific">Specific</option>
                                                </select>
                                                 @error('category')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="sector">Sector</label><span style="color:red;">*</span>
                                                <select name="sector" id="sector" class="form-control project_box">
                                                  <option value="">Select Option</option>
                                                    @foreach($sectorname as $tn)
                                                    <option value="{{$tn->sector_name}}">{{$tn->sector_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('sector')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="conditionno">Condition No.</label><span style="color:red;">*</span>
                                                <input type="text" name="conditionno" id="conditionno" value="{{ old('conditionno') }}" maxlength="10" class="form-control project_box">
                                                 @error('conditionno')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="user_name">User</label><span style="color:red;">*</span>
                                                
                                                <select name="user_name" id="user_name" class="form-control project_box">
                                                        <option value="">Select Option</option>
                                                    @foreach($username as $un)
                                                    <option value="{{$un->id}}">{{$un->first_name}}  {{$un->last_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('user_name')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="tasktype">type</label><span style="color:red;">*</span>
                                                <select name="tasktype" id="tasktype" class="form-control project_box">
                                                        <option value="">Select Option</option>
                                                     @foreach($stagesname as $sgn)
                                                    <option value="{{$sgn->stage_name}}">{{$sgn->stage_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('tasktype')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="taskstatus">Task Status</label><span style="color:red;">*</span>
                                                <select name="taskstatus" id="taskstatus" class="form-control project_box">
                                                       <option value="">Select Option</option>
                                                   @foreach($statusname as $sn)
                                                    <option value="{{$sn->status_name}}">{{$sn->status_name}}</option>
                                                    @endforeach
                                                </select>
                                                 @error('taskstatus')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="startdate">Start Date</label><span style="color:red;">*</span>
                                                <input type="text" name="startdate" placeholder="dd/mm/yyyy" id="startdate" value="{{ old('startdate') }}" class="dateTxt form-control project_box">
                                                 @error('startdate')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="endDate">End Date</label><span style="color:red;">*</span>
                                                <input type="text" name="endDate" id="endDate" placeholder="dd/mm/yyyy" value="{{ old('endDate') }}" class="dateTxt form-control project_box">
                                                 @error('endDate')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="taskDescription">Task Description</label><span style="color:red;">*</span>
                                                <textarea rows="4" name="taskDescription" maxlength="255" id="taskDescription" class="form-control project_box">{{ old('taskDescription') }}</textarea>
                                                 @error('taskDescription')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="estimatedhours">Estimated Hours</label><span style="color:red;">*</span>
                                                <input type="text" onkeypress="preventNonNumericalInput(event)" name="estimatedhours" id="estimatedhours" maxlength="4"  value="{{ old('estimatedhours') }}" class="form-control project_box">
                                                 @error('estimatedhours')
                                                <div style="color:red;">{{ $message }}</div>
                                                @enderror	
                                            </div>
                                        </div>

                                        <div class="col-xs-12 col-sm-12 text-center">
                                                <button type="button" data-toggle="modal" data-target="#exampleModalScrollable" class="previvew_btn">Preview</button>
                                                <input type="submit" name="submit" value="Submit" class="submit_btn">
                                        </div>

                                        <!-- <div class="col-xs-12 col-sm-6">
                                            <div class="see_details">
                                                <p>Click <a href="task_details.html">here</a> to see project details.</p>
                                            </div>
                                        </div> -->
                                    </div>
                                </form> 
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- content -->
            <!-- <footer class="footer">© 2019 GRC </footer> -->
        </div>
   @stop
   
   @section('extra_js')
   
   <script>

$(document).on('click','.submit_btn',function(){
    
    fromdate = $('#startdate').val();
    todate = $('#endDate').val();
    
    
      var d1 = Date.parse(fromdate);
                  var d2 = Date.parse(todate);
                  if (d1 > d2) {
                      alert ("Please Select Valid Date");
                      var error = 0;
                      return false;
                  }
    
});
$(function(){$('.dateTxt').datepicker(); }); 
</script>
   
   @stop